package com.ipl.controller;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.ipl.model.IPLModel;
import com.ipl.modellog.IPLLoginModel;
import com.ipl.service.IPLService;

@RestController
public class IPLController {
@Autowired
	IPLService IPLSer;

			@GetMapping("/getLoginData")
			public List<IPLLoginModel> getLogin()
			{
				return IPLSer.getLoginData();
			}
			@PostMapping("/login")
			public String Login(@RequestBody Map<String,String> data)
			{
				String userEmail = data.get("email");
				String userPassword = data.get("password");
				return IPLSer.Login(userEmail,userPassword);
			}
			@PostMapping("/addUser")
			public IPLLoginModel addUser(@RequestBody IPLLoginModel data)
			{
				return IPLSer.addUser(data);
			}
			
			@GetMapping("/sortDataAsc/{field}")
			public List<IPLModel> sortDataByAsc(@PathVariable("field") String data)
			{
				return IPLSer.sortDataByAsc(data);
			}
			@GetMapping("/sortDataDesc/{field}")
			public List<IPLModel> sortDataByDesc(@PathVariable("field") String data)
			{
				return IPLSer.sortDataByDesc(data);
			}
			@GetMapping("/pageData/{offset}/{noofrecords}")
			public Page<IPLModel> pageData(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords)
			{
				return IPLSer.pageData(pageNo,noOfRecords);
			}
			@GetMapping("/pageListData/{offset}/{noofrecords}")
			public List<IPLModel> pageListData(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords)
			{
				return IPLSer.pageListData(pageNo,noOfRecords);
			}
			@GetMapping("/pageListDataAsc/{offset}/{noofrecords}/{field}")
			public List<IPLModel> pageListDataAsc(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords,@PathVariable("field") String data)
			{
				return IPLSer.pageListDataAsc(pageNo,noOfRecords,data);
			}
			@GetMapping("/pageListDataDesc/{offset}/{noofrecords}/{field}")
			public List<IPLModel> pageListDataDesc(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords,@PathVariable("field") String data)
			{
				return IPLSer.pageListDataDesc(pageNo,noOfRecords,data);
			}
}