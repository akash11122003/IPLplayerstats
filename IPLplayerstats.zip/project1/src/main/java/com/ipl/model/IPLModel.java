package com.ipl.model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;



@Entity
public class IPLModel {
	@Id
	private String ifullname;
	
	private int ijerno;
	
	private String iteam;

	private String itype;

	private String istyle;
	
	private int imatch;
	
	private long iruns;

	private float iaverage;

	private long iwickets;
	
	private float ieconomy;
	
	public String getIfullname() {
		return ifullname;
	}
	public void setIfullname(String ifullname) {
		this.ifullname = ifullname;
	}
	public int getIjerno() {
		return ijerno;
	}
	public void setIjerno(int ijerno) {
		this.ijerno = ijerno;
	}
	public String getIteam() {
		return iteam;
	}
	public void setIteam(String iteam) {
		this.iteam = iteam;
	}
	public String getItype() {
		return itype;
	}
	public void setItype(String itype) {
		this.itype = itype;
	}
	public String getIstyle() {
		return istyle;
	}
	public void setIstyle(String istyle) {
		this.istyle = istyle;
	}
	public int getImatch() {
		return imatch;
	}
	public void setImatch(int imatch) {
		this.imatch = imatch;
	}
	public long getIruns() {
		return iruns;
	}
	public void setIruns(long iruns) {
		this.iruns = iruns;
	}
	public float getIaverage() {
		return iaverage;
	}
	public void setIaverage(float iaverage) {
		this.iaverage = iaverage;
	}
	public long getIwickets() {
		return iwickets;
	}
	public void setIwickets(long iwickets) {
		this.iwickets = iwickets;
	}
	public float getIeconomy() {
		return ieconomy;
	}
	public void setIeconomy(float ieconomy) {
		this.ieconomy = ieconomy;
	}
	
	
	
	
}
	