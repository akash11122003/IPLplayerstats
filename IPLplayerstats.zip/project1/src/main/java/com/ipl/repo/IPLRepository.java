package com.ipl.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ipl.model.IPLModel;
public interface IPLRepository extends JpaRepository<IPLModel, String>
{
	

}
