package com.ipl.repolog;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ipl.modellog.IPLLoginModel;
public interface IPLLoginRepository extends JpaRepository<IPLLoginModel, String>
{
	


}