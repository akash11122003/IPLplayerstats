package com.ipl.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.ipl.model.IPLModel;
import com.ipl.modellog.IPLLoginModel;
import com.ipl.repo.IPLRepository;
import com.ipl.repolog.IPLLoginRepository;

@Service
public class IPLService {
@Autowired
IPLRepository IPLrep;
@Autowired
IPLLoginRepository logrep;

public String Login(String email, String password) {
	try {
	IPLLoginModel userEmail =logrep.findById(email).get();
	if(userEmail == null)
	{
		return "Account isn't found or email incorrect";
	}
	else 
	{
		if((userEmail.getPassword()).equals(password))
		{
			return "Login Successfull";
		}
		else
		{
			return "Login Unsuccessfull! Check email and password";
		}
	}
	}
	catch(Exception e)
	{
		return "Login Unsuccessfull! Check email and password";
	}
}

public List<IPLLoginModel> getLoginData() {
	return logrep.findAll();
}

public IPLLoginModel addUser(IPLLoginModel data) {
	return logrep.save(data);
}

public List<IPLModel> getData() {
	return IPLrep.findAll();
}

public IPLModel putData(IPLModel data) {
	return IPLrep.save(data);
}

public List<IPLModel> sortDataByAsc(String field) {
	return IPLrep.findAll(Sort.by(field));
}
public List<IPLModel> sortDataByDesc(String field) {
	return IPLrep.findAll(Sort.by(Direction.DESC,field));
}

public Page<IPLModel> pageData(int pageNo, int noOfRecords) {
	Pageable data=PageRequest.of(pageNo, noOfRecords);
	Page<IPLModel> pData=IPLrep.findAll(data);
	return pData;
}

public List<IPLModel> pageListData(int pageNo, int noOfRecords) {
	Pageable data=PageRequest.of(pageNo, noOfRecords);
	Page<IPLModel> pData=IPLrep.findAll(data);
	return pData.getContent();
}
public List<IPLModel> pageListDataAsc(int pageNo, int noOfRecords,String field) {
	Pageable data=PageRequest.of(pageNo, noOfRecords).withSort(Sort.by(field));
	Page<IPLModel> pData=IPLrep.findAll(data);
	return pData.getContent();
}
public List<IPLModel> pageListDataDesc(int pageNo, int noOfRecords,String field) {
	Pageable data=PageRequest.of(pageNo, noOfRecords).withSort(Sort.by(Direction.DESC,field));
	Page<IPLModel> pData=IPLrep.findAll(data);
	return pData.getContent();
}
}